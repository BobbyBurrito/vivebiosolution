import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Calendar } from "lucide-react";

/**
 * Design Philosophy: Premium Bio-Solutions - Blog Section
 * - Clean, professional layout for thought leadership
 * - Teal/green accent colors consistent with brand
 * - Featured blog cards with images and metadata
 * - Easy navigation and content discovery
 */

interface BlogPost {
  id: string;
  date: string;
  title: string;
  description: string;
  image: string;
  category: string;
}

const blogPosts: BlogPost[] = [
  {
    id: "1",
    date: "April 8, 2026",
    title: "Optimizing Biological Activity for Superior Results",
    description: "Discover the science behind maximizing biological effectiveness for FOG destruction in commercial grease traps.",
    image: "https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "Science",
  },
  {
    id: "2",
    date: "March 22, 2026",
    title: "Windsor FOG Bylaw: What You Need to Know",
    description: "A guide for Windsor-Essex restaurant owners on staying compliant and avoiding costly municipal fines.",
    image: "https://images.unsplash.com/photo-1581092335397-9583eb92d232?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "Compliance",
  },
  {
    id: "3",
    date: "March 10, 2026",
    title: "The Science of Septic: Multi-Action Biological Formulas",
    description: "Understand why comprehensive biological formulas are crucial for effectively breaking down diverse waste in modern residential septic systems.",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "Technology",
  },
];

export default function Blog() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <img
              src="/manus-storage/vive-logo_b9acb25d.jpeg"
              alt="Vive Bio Solution Logo"
              className="h-12 w-auto"
            />
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="/#products" className="text-sm font-medium text-slate-700 hover:text-teal-600 transition">
              Products
            </a>
            <a href="/#advantages" className="text-sm font-medium text-slate-700 hover:text-teal-600 transition">
              Why Vive Bio
            </a>
            <a href="/blog" className="text-sm font-medium text-teal-600 font-semibold">
              Blog
            </a>
            <a href="/#contact" className="text-sm font-medium text-slate-700 hover:text-teal-600 transition">
              Contact
            </a>
          </nav>
          <Button className="bg-teal-600 hover:bg-teal-700 text-white">Get Quote</Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-teal-50 via-blue-50 to-green-50">
        <div className="container max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 leading-tight">
            Insights from the Lab
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Expert advice, industry news, and science-backed answers to your most common questions about bio-enzymatic solutions.
          </p>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-16 md:py-24 px-4">
        <div className="container max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card key={post.id} className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition flex flex-col">
                {/* Blog Image */}
                <div className="h-48 overflow-hidden bg-slate-200">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover hover:scale-105 transition duration-300"
                  />
                </div>

                {/* Blog Content */}
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="h-4 w-4 text-teal-600" />
                    <span className="text-sm text-slate-500">{post.date}</span>
                  </div>
                  <div className="mb-2">
                    <span className="inline-block px-3 py-1 bg-teal-100 text-teal-700 text-xs font-semibold rounded-full">
                      {post.category}
                    </span>
                  </div>
                  <CardTitle className="text-xl text-slate-900 leading-tight">
                    {post.title}
                  </CardTitle>
                </CardHeader>

                <CardContent className="flex-grow pb-4">
                  <p className="text-slate-600 text-sm leading-relaxed mb-6">
                    {post.description}
                  </p>
                </CardContent>

                {/* Read More Button */}
                <div className="px-6 pb-6">
                  <Button
                    variant="outline"
                    className="w-full border-teal-600 text-teal-600 hover:bg-teal-50 group"
                  >
                    Read Article
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 md:py-24 px-4 bg-slate-900 text-white">
        <div className="container max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Stay Informed. Stay Compliant.</h2>
          <p className="text-slate-300 mb-8">
            Subscribe to our newsletter for the latest industry insights, compliance updates, and bio-enzymatic innovations.
          </p>
          <form className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            <Button className="bg-teal-600 hover:bg-teal-700 text-white px-8">
              Subscribe
            </Button>
          </form>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 px-4">
        <div className="container max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">
            Ready to Optimize Your Operations?
          </h2>
          <p className="text-lg text-slate-600 mb-8 max-w-2xl mx-auto">
            Connect with our Windsor engineering team to discuss how our bio-enzymatic solutions can improve your facility's efficiency and compliance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-teal-600 hover:bg-teal-700 text-white">
              Request a Consultation
            </Button>
            <Button size="lg" variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-50">
              View Products
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8 px-4 border-t border-slate-800">
        <div className="container max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="text-white font-bold mb-4">About Vive Bio</h4>
              <p className="text-sm">
                Windsor-engineered bio-enzymatic solutions for industrial cleaning and environmental responsibility.
              </p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Quick Links</h4>
              <ul className="text-sm space-y-2">
                <li><a href="/" className="hover:text-teal-400 transition">Home</a></li>
                <li><a href="/#products" className="hover:text-teal-400 transition">Products</a></li>
                <li><a href="/blog" className="hover:text-teal-400 transition">Blog</a></li>
                <li><a href="/#contact" className="hover:text-teal-400 transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Contact</h4>
              <p className="text-sm">
                <a href="tel:+15199925101" className="hover:text-teal-400 transition">+1-519-992-5101</a><br />
                <a href="mailto:Info@vivebiosolution.ca" className="hover:text-teal-400 transition">Info@vivebiosolution.ca</a>
              </p>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-sm">
            <p>&copy; 2026 Vive Bio Solution. All rights reserved. Made in Canada.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
