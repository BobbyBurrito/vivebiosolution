from bs4 import BeautifulSoup

with open('/home/ubuntu/browser_html/vivebiosolution_ca_blog_1776706808647.html', 'r') as f:
    soup = BeautifulSoup(f, 'html.parser')

# Find all blog cards
blog_cards = soup.find_all('div', class_='blog-card') or soup.find_all('article') or soup.find_all('div', {'data-testid': 'blog-post'})

if not blog_cards:
    # Try finding by looking for common blog structures
    blog_items = soup.find_all('div', class_=lambda x: x and 'blog' in x.lower())
    print(f"Found {len(blog_items)} blog-related divs")
    
    # Look for the main content area
    main_content = soup.find('main') or soup.find('section', class_=lambda x: x and 'blog' in x.lower())
    if main_content:
        print("\nMain content area found:")
        print(main_content.prettify()[:2000])
else:
    print(f"Found {len(blog_cards)} blog cards")
    for i, card in enumerate(blog_cards):
        print(f"\n--- Blog {i+1} ---")
        print(card.prettify()[:500])
