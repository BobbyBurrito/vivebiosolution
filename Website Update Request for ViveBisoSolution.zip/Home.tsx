import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, Droplets, Zap } from "lucide-react";
import { useState } from "react";

/**
 * Design Philosophy: Premium Bio-Solutions
 * - Clean, professional layout emphasizing scientific credibility
 * - Teal/green accent colors reflecting bio-enzymatic nature
 * - Product-focused with clear pricing and value propositions
 * - Strong CTA for quotes and contact
 */

export default function Home() {
  const [activeTab, setActiveTab] = useState("products");

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <img
              src="/manus-storage/vive-logo_b9acb25d.jpeg"
              alt="Vive Bio Solution Logo"
              className="h-12 w-auto"
            />
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#products" className="text-sm font-medium text-slate-700 hover:text-teal-600 transition">
              Products
            </a>
            <a href="#advantages" className="text-sm font-medium text-slate-700 hover:text-teal-600 transition">
              Why Vive Bio
            </a>
            <a href="/blog" className="text-sm font-medium text-slate-700 hover:text-teal-600 transition">
              Blog
            </a>
            <a href="#contact" className="text-sm font-medium text-slate-700 hover:text-teal-600 transition">
              Contact
            </a>
          </nav>
          <Button className="bg-teal-600 hover:bg-teal-700 text-white">Get Quote</Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-teal-50 via-blue-50 to-green-50">
        <div className="container max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 leading-tight">
            Advanced Bio-Enzymatic Solutions for Industrial Cleaning
          </h1>
          <p className="text-lg text-slate-600 mb-8 max-w-2xl mx-auto">
            Windsor-engineered, environmentally responsible products that destroy grease, oils, and grime at the molecular level.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-teal-600 hover:bg-teal-700 text-white">
              View Products
            </Button>
            <Button size="lg" variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-50">
              Request Free Sample
            </Button>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-16 md:py-24 px-4">
        <div className="container max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Our Product Line</h2>
            <p className="text-lg text-slate-600">
              Two powerful solutions engineered for maximum performance and environmental responsibility
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* VIVE-DRAIN FOG Terminator */}
            <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition">
              <div className="bg-gradient-to-br from-teal-500 to-blue-600 h-64 flex items-center justify-center p-4">
                <img
                  src="/manus-storage/vive-drain-product_d5fc7ef8.png"
                  alt="VIVE-DRAIN FOG Terminator"
                  className="h-full object-contain"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl text-slate-900">VIVE-DRAIN FOG Terminator</CardTitle>
                <CardDescription className="text-base">Bio-Enzymatic FOG Destroyer</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-teal-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">8 billion live bacteria per litre</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-teal-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">Reduces pump-out frequency by 3x</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-teal-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">Chemical-free & environmentally safe</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-teal-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">WHMIS 2022 compliant</span>
                  </div>
                </div>

                {/* Pricing & Savings */}
                <div className="bg-teal-50 border border-teal-200 rounded-lg p-4">
                  <div className="mb-3">
                    <p className="text-sm text-slate-600">Starting Price</p>
                    <p className="text-3xl font-bold text-teal-700">$16 <span className="text-lg text-slate-600">/litre</span></p>
                  </div>
                  <p className="text-sm text-slate-700 mb-3">
                    <strong>Bulk discounts available</strong> for large orders
                  </p>
                  <p className="text-sm text-slate-600 italic">
                    💰 Save significantly on pump-out costs with 3x reduction in frequency
                  </p>
                </div>

                <Button className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                  Get Quote
                </Button>
              </CardContent>
            </Card>

            {/* VIVE-SHIFT Industrial Degreaser */}
            <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition">
              <div className="bg-gradient-to-br from-emerald-500 to-teal-600 h-64 flex items-center justify-center p-4">
                <img
                  src="/manus-storage/vive-shift-product_298fdf69.png"
                  alt="VIVE-SHIFT Industrial Degreaser"
                  className="h-full object-contain"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl text-slate-900">VIVE-SHIFT Industrial Degreaser</CardTitle>
                <CardDescription className="text-base">100% Solvent-Free & Biodegradable</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">Advanced enzyme-based formula</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">Removes industrial oils, dirt & grime</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">100% solvent-free & chemical-free</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">Safe for oil-water separators</span>
                  </div>
                </div>

                {/* Pricing */}
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                  <p className="text-sm text-slate-600 mb-2">Pricing</p>
                  <p className="text-lg font-semibold text-emerald-700 mb-3">
                    Custom pricing based on volume
                  </p>
                  <p className="text-sm text-slate-600 italic">
                    Contact us for a personalized quote for your industrial cleaning needs
                  </p>
                </div>

                <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                  Request Quote
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Vive Bio Section */}
      <section id="advantages" className="py-16 md:py-24 px-4 bg-slate-900 text-white">
        <div className="container max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">The Vive Bio Advantage</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-teal-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Zap className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Direct Manufacturer</h3>
              <p className="text-slate-300">
                We formulate and bottle everything in Windsor. You get direct pricing and expert support.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-teal-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Droplets className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Higher Bacterial Count</h3>
              <p className="text-slate-300">
                8 billion CFU per litre—significantly more active biology than standard alternatives.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-teal-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Check className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Full Canadian Compliance</h3>
              <p className="text-slate-300">
                DSL verified and WHMIS 2022 compliant with bilingual documentation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact & Quote Section */}
      <section id="contact" className="py-16 md:py-24 px-4">
        <div className="container max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Get in Touch</h2>
            <p className="text-lg text-slate-600">
              Connect with our Windsor engineering team for samples, pricing, and custom dosing protocols
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Contact Info */}
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-4">Direct Manufacturer Support</h3>
                <div className="space-y-3 text-slate-700">
                  <p>
                    <strong>Phone:</strong> <a href="tel:+15199925101" className="text-teal-600 hover:underline">+1-519-992-5101</a>
                  </p>
                  <p>
                    <strong>Email:</strong> <a href="mailto:Info@vivebiosolution.ca" className="text-teal-600 hover:underline">Info@vivebiosolution.ca</a>
                  </p>
                  <p>
                    <strong>Location:</strong> Windsor, Ontario, Canada
                  </p>
                  <p>
                    <strong>Hours:</strong> 24/7 Emergency Support Available
                  </p>
                </div>
              </div>

              <div className="bg-teal-50 border border-teal-200 rounded-lg p-4">
                <h4 className="font-bold text-slate-900 mb-2">Serving Southern Ontario</h4>
                <p className="text-sm text-slate-700">
                  Windsor, LaSalle, Tecumseh, Amherstburg, Essex, Kingsville, Leamington, Chatham, Tilbury, Sarnia, and London
                </p>
              </div>
            </div>

            {/* Quick Quote Form */}
            <div className="bg-gradient-to-br from-teal-50 to-blue-50 border border-teal-200 rounded-lg p-6">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Quick Quote Request</h3>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Product Interest *</label>
                  <select
                    required
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="">Select a product</option>
                    <option value="drain">VIVE-DRAIN FOG Terminator</option>
                    <option value="shift">VIVE-SHIFT Industrial Degreaser</option>
                    <option value="both">Both Products</option>
                    <option value="inquiry">General Inquiry</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Message</label>
                  <textarea
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                    rows={3}
                    placeholder="Tell us about your needs..."
                  />
                </div>
                <Button className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                  Send Request
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8 px-4 border-t border-slate-800">
        <div className="container max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="text-white font-bold mb-4">About Vive Bio</h4>
              <p className="text-sm">
                Windsor-engineered bio-enzymatic solutions for industrial cleaning and environmental responsibility.
              </p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Products</h4>
              <ul className="text-sm space-y-2">
                <li><a href="#products" className="hover:text-teal-400 transition">VIVE-DRAIN FOG Terminator</a></li>
                <li><a href="#products" className="hover:text-teal-400 transition">VIVE-SHIFT Industrial Degreaser</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Contact</h4>
              <p className="text-sm">
                <a href="tel:+15199925101" className="hover:text-teal-400 transition">+1-519-992-5101</a><br />
                <a href="mailto:Info@vivebiosolution.ca" className="hover:text-teal-400 transition">Info@vivebiosolution.ca</a>
              </p>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-sm">
            <p>&copy; 2026 Vive Bio Solution. All rights reserved. Made in Canada.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
