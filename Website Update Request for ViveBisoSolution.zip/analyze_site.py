from bs4 import BeautifulSoup

with open('/home/ubuntu/browser_html/vivebiosolution_ca_page_1776705146504.html', 'r') as f:
    soup = BeautifulSoup(f, 'html.parser')

# Look for the logo
logo_link = soup.find('a', {'href': '/'})
if logo_link:
    print("Logo Link Found:")
    print(logo_link.prettify())
    img = logo_link.find('img')
    if img:
        print("Logo Image Tag:")
        print(img.prettify())
    else:
        print("No img tag inside logo link.")

# Look for the contact form
form = soup.find('form')
if form:
    print("\nContact Form Found:")
    print(form.prettify())
else:
    # Try finding by common IDs or classes
    form = soup.find('div', {'id': 'contact'}) or soup.find('section', {'id': 'contact'})
    if form:
        print("\nContact Section Found:")
        print(form.prettify())
    else:
        print("\nNo contact form or section found on homepage.")
