from bs4 import BeautifulSoup

with open('/home/ubuntu/browser_html/vivebiosolution_ca_contact_1776705162008.html', 'r') as f:
    soup = BeautifulSoup(f, 'html.parser')

# Look for the contact form
form = soup.find('form')
if form:
    print("\nContact Form Found:")
    print(form.prettify())
else:
    print("\nNo form tag found. Looking for common container IDs...")
    container = soup.find('div', {'id': 'contact'}) or soup.find('section', {'id': 'contact'})
    if container:
        print("\nContact Section Found:")
        print(container.prettify())
    else:
        print("\nNo contact form or section found.")
